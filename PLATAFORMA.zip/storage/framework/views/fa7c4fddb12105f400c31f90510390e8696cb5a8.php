

<?php $__env->startSection('content'); ?>

<section class="full-width pageContent">
   
    <div class="mdl-tabs mdl-js-tabs mdl-js-ripple-effect">
        
        <td><img class="itecsur" src="<?php echo e(asset('imagen/20240522224050.png')); ?>" ></td>
     
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/home.blade.php ENDPATH**/ ?>