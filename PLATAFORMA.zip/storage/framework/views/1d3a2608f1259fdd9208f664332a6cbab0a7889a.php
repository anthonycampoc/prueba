

<?php $__env->startSection('content'); ?>

<section class="full-width pageContent">
    <div class="mdl-tabs mdl-js-tabs mdl-js-ripple-effect">
        <div class="mdl-tabs__tab-bar">
            <a href="#tabNewAdmin" class="mdl-tabs__tab is-active">Roles</a>
        </div>
        <div class="mdl-tabs__panel is-active" id="tabNewAdmin">
            <div class="mdl-grid">
                <div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--12-col-desktop">
                    <div class="full-width panel mdl-shadow--2dp">
                        <div class="full-width panel-tittle bg-primary text-center tittles">
                            Actualizar Rol
                        </div>
                        <div class="full-width panel-content">
                     
                                <div class="mdl-grid">
                               
                                    <div class="mdl-cell mdl-cell--4-col-phone mdl-cell--8-col-tablet mdl-cell--6-col-desktop">
                                        <h5 class="text-condensedLight">Detalle de Usuario</h5>
                                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                            <input value="<?php echo e($users->name); ?>" class="mdl-textfield__input" disabled type="text" id="UserNameAdmin">
                                        
                                         
                                        </div>
                                        <h5 class="text-condensedLight">Lista de Roles</h5>

                                       <?php echo Form::model($users,['route'=>['users.update', $users], 'method' => 'put']); ?>

                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <label  class="mdl-radio mdl-js-radio mdl-js-ripple-effect">
                                                        <?php echo Form::checkbox('roles[]', $item->id, null,['class'=>'mdl-radio__button']); ?>

                                                        <span class="mdl-radio__label"><?php echo e($item->name); ?></span>
                                                    </label>
                                                    <br><br>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <p class="text-center">
                                                <button class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored bg-primary" id="btn-addAdmin">
                                                    <i class="zmdi zmdi-plus"></i>
                                                </button>
                                                <div class="mdl-tooltip" for="btn-addAdmin">Actualizar Rol</div>
                                            </p>
                                       <?php echo Form::close(); ?>

                                       
                                    </div>
                                </div>
                             
                     
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prueba\resources\views/adminPC/usuarios/editUsuario.blade.php ENDPATH**/ ?>