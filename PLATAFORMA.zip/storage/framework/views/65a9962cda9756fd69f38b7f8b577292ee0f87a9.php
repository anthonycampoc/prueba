<!-- resources/views/clientes/edit.blade.php -->
<h1>Editar Cliente</h1>
<form action="<?php echo e(route('cliente.update', $cliente)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input type="text" name="nombre" value="<?php echo e($cliente->nombre); ?>" required>
    <input type="text" name="cedula" value="<?php echo e($cliente->cedula); ?>" required>
    <input type="email" name="email" value="<?php echo e($cliente->email); ?>" required>
    <input type="text" name="telefono" value="<?php echo e($cliente->telefono); ?>" required>
    <!-- Agrega los campos restantes según tus necesidades -->
    <button type="submit">Actualizar</button>
</form>
<?php /**PATH C:\xampp\htdocs\prueba\resources\views/clientes/editarCliente.blade.php ENDPATH**/ ?>