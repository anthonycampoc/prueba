
<h1>Crear Cliente</h1>
<form action="<?php echo e(route('cliente.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="nombre" placeholder="Nombre" required>
    <input type="text" name="cedula" placeholder="Cédula" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="telefono" placeholder="Teléfono" required>
    
    <!-- Agrega los campos restantes según tus necesidades -->
    <button type="submit">Guardar</button>
</form>
<?php /**PATH C:\xampp\htdocs\prueba\resources\views/clientes/crearClientes.blade.php ENDPATH**/ ?>