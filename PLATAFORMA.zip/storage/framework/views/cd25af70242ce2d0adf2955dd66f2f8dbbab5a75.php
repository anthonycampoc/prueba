
<h1>Lista de Clientes</h1>
<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Cédula</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Fecha de Nacimiento</th>
            <th>Provincia</th>
            <th>Cantón</th>
            <th>Parroquia</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cliente->nombre); ?></td>
                <td><?php echo e($cliente->cedula); ?></td>
                <td><?php echo e($cliente->email); ?></td>
                <td><?php echo e($cliente->telefono); ?></td>
                <td><?php echo e($cliente->fecha_nacimiento); ?></td>
                <td><?php echo e($cliente->provincia); ?></td>
                <td><?php echo e($cliente->canton); ?></td>
                <td><?php echo e($cliente->parroquia); ?></td>
                <td>
                    <a href="<?php echo e(route('cliente.show', $cliente)); ?>">Ver</a>
                    <a href="<?php echo e(route('cliente.edit', $cliente)); ?>">Editar</a>
                    <form action="<?php echo e(route('cliente.destroy', $cliente)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="<?php echo e(route('cliente.create')); ?>">Crear nuevo cliente</a>
<?php /**PATH C:\xampp\htdocs\prueba\resources\views/clientes/mostrarClientes.blade.php ENDPATH**/ ?>