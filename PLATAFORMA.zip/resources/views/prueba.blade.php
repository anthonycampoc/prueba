<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>mira tu correo que te mande un invitacion al repositorio</p>
    <p>pon tu correo de git y luego tu usuario</p> Kevinrente
    <h1>NUEVO</h1>

    <h2>NUEVO</h2>

    <p>ya loco ya quedo todo estable</p>
</body>
</html>