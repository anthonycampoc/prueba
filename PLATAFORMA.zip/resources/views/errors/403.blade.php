@extends('layouts.admin')

@section('content')

<section class="full-width pageContent">
   
    <div class="mdl-tabs mdl-js-tabs mdl-js-ripple-effect">
        
        <td><img class="itecsur" src="{{asset('imagen/20240522224050.png')}}" ></td>
     
    </div>
</section>



@endsection
